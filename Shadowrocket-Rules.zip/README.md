# Shadowrocket Rules

这个仓库包含 Shadowrocket 配置及规则集：
- Shadowrocket.conf ：主配置文件
- ChinaDirectSecure.list ：国内服务直连规则
- GlobalProxy.list ：国外通用代理规则

使用方法：
1. 在 Shadowrocket 中导入 `Shadowrocket.conf`。
2. 配置节点即可自动分流国内/国外流量。
3. 所有规则可通过 `RULE-SET` 自动更新。